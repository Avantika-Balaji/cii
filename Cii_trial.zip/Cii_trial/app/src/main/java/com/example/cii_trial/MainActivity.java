package com.example.cii_trial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button b1;
    Button b2;
    Button b3;
    EditText e1;
    EditText e2;
    EditText e3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText3);
        e3=findViewById(R.id.editText4);
        b3=findViewById(R.id.button3);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                e1.setVisibility(View.VISIBLE);
                e2.setVisibility(View.INVISIBLE);
                e3.setVisibility(View.VISIBLE);
                b3.setText("LOGIN");

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setVisibility(View.INVISIBLE);
                e2.setVisibility(View.VISIBLE);
                e3.setVisibility(View.INVISIBLE);
                b3.setText("Request OTP");
            }
        });
    }
}
